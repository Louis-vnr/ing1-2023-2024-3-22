#include <stdio.h>
#include <stdlib.h>
#include <windows.h>
#include <conio.h>
#include <stdbool.h>
#define LONGUEUR 10
#define LARGEUR 20

void gotoligcol( int lig, int col ) {
    COORD mycoord;
    int x, y;
    mycoord.X = col;
    mycoord.Y = lig;
    SetConsoleCursorPosition(GetStdHandle(STD_OUTPUT_HANDLE), mycoord);
}
struct Snoopy{
    int x,y;
    int vie;
    int score;
    int oiseaux;
    int mort;
};
struct Balle{
int x,y,directionX,directionY;
};

bool collisionBalle(struct Snoopy snoopy,struct Balle balle){
    return(snoopy.x==balle.x&&snoopy.y==balle.y);
}
void effacerBalle(struct Balle balle){
    gotoligcol(balle.y, balle.x);
    printf(" ");
}
void affichageBalle(struct Balle *balle, char matrice [LONGUEUR][LARGEUR]){
    gotoligcol(balle->y, balle->x);
    printf("o");

}

void deplacementBalle(struct Balle *balle,char matrice[LONGUEUR][LARGEUR]){
    balle->x+=balle->directionX;
    balle->y+=balle->directionY;
    if(matrice[balle->y][balle->x]!=' '){
        balle->x+=balle->directionX;
        balle->y+=balle->directionY;
    }
    if(balle->x>=LARGEUR-2 || balle->x<2) {
        balle->directionX = -balle->directionX;
    }
    if(balle->y>=LONGUEUR-2 || balle->y<2)
        balle->directionY=-balle->directionY;
}
bool deplacementSnoopy(struct Snoopy *snoopy,char matrice[LONGUEUR][LARGEUR]){
    int instruction;
    if(_kbhit()){
        gotoligcol(snoopy->y,snoopy->x);
        instruction=_getch();
    switch(instruction){
        case 'H':
            if((snoopy->y>1) && matrice[snoopy->y-1][snoopy->x]!='*')
                snoopy->y--;
        break;
        case 'P':
            if((snoopy->y<LONGUEUR-2)&&matrice[snoopy->y+1][snoopy->x]!='*')
                snoopy->y++;
        break;
        case 'M':
            if(snoopy->x<LARGEUR-2 && matrice[snoopy->y][snoopy->x+1]!='*')
            snoopy->x++;
        break;
        case 'K':
            if(snoopy->x>1 && matrice[snoopy->y][snoopy->x-1]!='*')
            snoopy->x--;
        break;
            }
            printf(" ");
return true;}
    return false;}

void affichageSnoopy(struct Snoopy snoopy){
    gotoligcol(snoopy.y,snoopy.x);
    printf("S");
}

int main() {
    struct Snoopy snoopy = {4,8,3,0,0,0};
    struct Balle balle = {3,3,1,1};
    char matrice[LONGUEUR][LARGEUR];
        FILE *fichier = NULL;
        int x, y;
        char carac;
        fichier = fopen("test.txt", "r");
        if (fichier == NULL) {
            printf("Impossible d'ouvrir le fichier");
        }
        else {
            for (y = 0; y < 10; y++) {
                for (x = 0; x <= 20; x++) {
                    carac = fgetc(fichier);
                    matrice[y][x]=carac;
                    printf("%c", matrice[y][x]);
                }
            }
            fclose(fichier);
        }
        affichageSnoopy(snoopy);
        while(snoopy.mort!=1){
            Sleep(200);
            effacerBalle(balle);
            deplacementBalle(&balle,matrice);
            affichageBalle(&balle,matrice);
                if(collisionBalle(snoopy,balle)){
                    snoopy.vie=-1;
                    snoopy.mort++;
                }
                if(deplacementSnoopy(&snoopy, matrice)){
                    affichageSnoopy(snoopy);
                }
                if(matrice[snoopy.y][snoopy.x]=='X'){
                    snoopy.vie=-1;
                    system("cls");
                    snoopy.mort++;
                }
                if(matrice[snoopy.y][snoopy.x]=='F'){
                    matrice[snoopy.y][snoopy.x]=' ';
                    snoopy.oiseaux++;
                }
                if(snoopy.oiseaux==4){
                    system("cls");
                    printf(" Vous avez fini ce niveau!");
                }
        }
        system("cls");
        printf(" Vous etes morts! -1 vie :(");
        Sleep(3000);
        system("cls");
        printf("Voulez vous retourner au menu ou reprendre le niveau?\n1.Reprendre le niveau!\n2.Retourner au menu!");
        if(kbhit()){
            switch(getch()){
                case '1':

            }
        }
return 0;
}
