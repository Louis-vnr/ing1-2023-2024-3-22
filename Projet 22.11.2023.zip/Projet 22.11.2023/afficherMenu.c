#include <stdio.h>

int main() {
    int nombre,qcm; //ENTIER n<-0 nombre<-0
    char choix;    //CHARACTERE <- choix


    printf("\n");
    printf("Menu\n1. Regles du jeu\n2. Commencer une nouvelle partie\n3. Charger une partie\n4. Mot de passes\n5. Score\n6. Quitter le jeu"); // ECRIRE "Menu\n1. Regles du jeu\n2. Commencer une nouvelle partie\n3. Charger une partie\n4. Mot de passes\n5. Score\n6. Quitter le jeu"
    scanf("%s", &choix); //LIRE choix


    switch(choix){
        case '1': // SI choix == 1
        {
            printf("Rajouter la fonction afficherRegles");
            break;  //On ferme la premiere condition
        }
        case '2': // SI choix == 2
        {

        break;
        }
        case '3': // SI choix == 3
        {
            printf("Rajouter la fonction sauvegarderPartie");
            break;} //On ferme la condition
        case '4': // Si choix == 4
        {
            printf("Rajouter la fonction motdepasses");
            break;}
        case '5': // SI choix == '5'
            {
                printf(" Rajouter la fonction afficherScores");
            break;
            }
        case '6':
        {
        printf("Merci d'avoir joué!\n A la prochaine !");
        return 1;
        }

    }



}
