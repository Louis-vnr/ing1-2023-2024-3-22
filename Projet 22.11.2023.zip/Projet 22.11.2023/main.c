#include <stdio.h>
#include <stdlib.h>
#include <windows.h>
#include <conio.h>
#include <stdbool.h>
#define LONGUEUR 10
#define LARGEUR 20

void gotoligcol( int lig, int col ) {
    COORD mycoord;
    int x, y;
    mycoord.X = col;
    mycoord.Y = lig;
    SetConsoleCursorPosition(GetStdHandle(STD_OUTPUT_HANDLE), mycoord);
}
struct Carte{
    char vcarte[LONGUEUR][LARGEUR];
};
struct Snoopy{
    int x,y;
    int ax,ay;
    int vie;
    int score;
};
struct Oiseaux{
    int x,y;
};
struct Balle{
int x,y,directionX,directionY;
};


bool checkCollision(struct Snoopy vsnoopy,char carte[LONGUEUR][LARGEUR]){
    if(carte[vsnoopy.y][vsnoopy.x]=='#') //On verifie si c'est une bordure
        return true;
}
void affichageBalle(struct Balle balle){
    gotoligcol(balle.y, balle.x);
    printf("o");
}

bool checkOiseau(struct Snoopy snoopy, struct Oiseaux oiseaux){
    return (snoopy.x==oiseaux.x && snoopy.y==oiseaux.y);
}

void deplacementBalle(struct Balle balle){

}
bool deplacementSnoopy(struct Snoopy *snoopy,char carte[LONGUEUR][LARGEUR]){
    int instruction;
    if(_kbhit()){
        gotoligcol(snoopy->y,snoopy->x);
        printf(" ");
        gotoligcol(snoopy->y,snoopy->x);
        instruction=_getch();
    switch(instruction){
        case 'H':
                snoopy->y--;
        break;
        case 'P':
                snoopy->y++;
        break;
        case 'M':
            snoopy->x++;
        break;
        case 'K':
            snoopy->x--;
        break;
            }
            printf(" ");
return true;}
    return false;}

void affichageSnoopy(struct Snoopy snoopy){
    gotoligcol(snoopy.y,snoopy.x);
    printf("S");
}

void affichageCarte(){
    FILE *fichier = NULL;
    int x, y;
    char carac;
    char carte[y][x];
    fichier = fopen("niveau.txt", "r");
    if (fichier == NULL) {
        printf("Impossible d'ouvrir le fichier");
    } else {
        for (y = 0; y < 10; y++) {
            for (x = 0; x < 20; x++) {
                carac = fgetc(fichier);
                carte[y][x] = carac;
                printf("%c", carte[y][x]);
            }
        }
        fclose(fichier);
    }
}



int main() {

    struct Snoopy snoopy = {5,5,3,0};
    struct Balle balle = {3,3,1,1};
        FILE *fichier = NULL;
        int x, y;
        char carac;
        char carte[y][x];
        fichier = fopen("test.txt", "r");
        if (fichier == NULL) {
            printf("Impossible d'ouvrir le fichier");
        }
        else {
            for (y = 0; y < 10; y++) {
                for (x = 0; x < 20; x++) {
                    carac = fgetc(fichier);
                    carte[y][x] = carac;
                    printf("%c", carte[y][x]);
                }
            }
            fclose(fichier);
        }
        affichageSnoopy(snoopy);
        while(1){
                if(deplacementSnoopy(&snoopy, carte)){
                    affichageSnoopy(snoopy);
                }
        }
return 0;
}
